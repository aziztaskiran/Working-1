package aziz_taskiran_hw4;

/**
 *
 * @author aziz
 */
public class Person 
{
     public String element;
     public Person next;
     public int index;
}
