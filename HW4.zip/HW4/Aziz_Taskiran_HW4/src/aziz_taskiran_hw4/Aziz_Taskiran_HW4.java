package aziz_taskiran_hw4;

import java.io.IOException;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

/**
 *
 * @author aziz
 */
public class Aziz_Taskiran_HW4 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)  
    {
        Scanner input = new Scanner(System.in); 
        Hash_Table table=new Hash_Table();
        while(true)
        {
            String inp=input.nextLine();
            if(inp.isEmpty())
            {
                System.out.println("Error.");
            }
            else if(inp.equals("X"))
            {
                System.exit(0);
            }
            else if(inp.length()<3)
            {
                System.out.println("Error."); 
            }
            else if(inp.charAt(0)=='I' && inp.charAt(1)==' ')
            {
                String isim1="";
                int i=2;
                while(i<inp.length())
                {
                    isim1+=inp.charAt(i);
                    i++;
                }
                if(isim1.isEmpty() || isim1.charAt(0)==' ')
                {
                    System.out.println("Error."); 
                }
                else
                {
                    isim1=isim1.toUpperCase();
                    table.addPerson(isim1, 1);
                }
            } 
            else if(inp.charAt(0)=='D' && inp.charAt(1)==' ')
            {
                String isim1="";
                int i=2;
                while(i<inp.length())
                {
                    isim1+=inp.charAt(i);
                    i++;
                }
                if(isim1.isEmpty() || isim1.charAt(0)==' ')
                {
                    System.out.println("Error."); 
                }
                else
                {
                    isim1=isim1.toUpperCase();
                    table.deletePerson(isim1);
                }
            }
            else if(inp.charAt(0)=='L' && inp.charAt(1)==' ')
            {
                String isim1="";
                int i=2;
                while(i<inp.length())
                {
                    isim1+=inp.charAt(i);
                    i++;
                }
                if(isim1.isEmpty() || isim1.charAt(0)==' ')
                {
                    System.out.println("Error."); 
                }
                else
                {
                    isim1=isim1.toUpperCase();
                    table.listofFriend(isim1);
                }
            }
            else if(inp.charAt(0)=='O' && inp.charAt(1)==' ')
            {
                String isim1="";
                int i=2;
                while(i<inp.length())
                {
                    isim1+=inp.charAt(i);
                    i++;
                }
                if(isim1.isEmpty() || isim1.charAt(0)==' ')
                {
                    System.out.println("Error."); 
                }
                else
                {
                    isim1=isim1.toUpperCase();
                    table.ortakBul(isim1);
                }
            }
            else if(inp.charAt(0)=='F' && inp.charAt(1)==' ')
            {
                String isim1="";
                String isim2="";
                int i=2;
                while(inp.charAt(i)!=' ')
                {
                    isim1+=inp.charAt(i);
                    i++;
                    if(i>=inp.length())
                    {
                        break;
                    }
                }
                i++;
                while(i<inp.length())
                {    
                    isim2+=inp.charAt(i);
                    i++;
                }
                if(isim1.isEmpty() || isim1.charAt(0)==' ' || isim2.isEmpty() || isim2.charAt(0)==' ')
                {
                   System.out.println("Error."); 
                }
                else
                {
                    isim1=isim1.toUpperCase();
                    isim2=isim2.toUpperCase();
                    table.beFriend(isim1,isim2);
                }
            }
            else if(inp.charAt(0)=='E' && inp.charAt(1)==' ')
            {
                String isim1="";
                String isim2="";
                int i=2;
                while(inp.charAt(i)!=' ')
                {
                    isim1+=inp.charAt(i);
                    i++;
                    if(i>=inp.length())
                    {
                       break;
                    }
                }
                i++;
                while(i<inp.length())
                {
                    isim2+=inp.charAt(i);
                    i++;
                }
                if(isim1.isEmpty() || isim1.charAt(0)==' ' || isim2.isEmpty() || isim2.charAt(0)==' ')
                {
                    System.out.println("Error."); 
                }
                else
                {
                    isim1=isim1.toUpperCase();
                    isim2=isim2.toUpperCase();
                    table.deleteFriendship(isim1,isim2);
                }
            }
            else if(inp.charAt(0)=='S' && inp.charAt(1)==' ')
            {
                String isim1="";
                String isim2="";
                int i=2;
                while(inp.charAt(i)!=' ')
                {
                    isim1+=inp.charAt(i);
                    i++;
                    if(i>=inp.length())
                    {
                        break;
                    }
                }
                i++;
                while(i<inp.length())
                {
                    isim2+=inp.charAt(i);
                    i++;
                }
                if(isim1.isEmpty() || isim1.charAt(0)==' ' || isim2.isEmpty() || isim2.charAt(0)==' ')
                {
                    System.out.println("Error."); 
                }
                else
                {
                    isim1=isim1.toUpperCase();
                    isim2=isim2.toUpperCase();
                    table.areTheyFriend(isim1,isim2,1);
                }
            }
            else if(inp.charAt(0)=='R' && inp.charAt(1)==' ')
            {
                try
                {
                    File txt=new File(inp.substring(2, inp.length()));
                    FileReader reader = new FileReader(txt);
                    BufferedReader bufferReader = new BufferedReader(reader);
                    String line;
                    while((line = bufferReader.readLine()) != null) 
                    {
                        inp=line;
                        if(inp.isEmpty())
                        {
                            System.out.println("Error.");
                        }
                        else if(inp.equals("X"))
                        {
                            System.exit(0);
                        }
                        else if(inp.length()<3)
                        {
                            System.out.println("Error."); 
                        }
                        else if(inp.charAt(0)=='I' && inp.charAt(1)==' ')
                        {
                            String isim1="";
                            int i=2;
                            while(i<inp.length())
                            {
                                isim1+=inp.charAt(i);
                                i++;
                            }
                            if(isim1.isEmpty() || isim1.charAt(0)==' ')
                            {
                                System.out.println("Error."); 
                            }
                            else
                            {
                                isim1=isim1.toUpperCase();
                                table.addPerson(isim1, 1);
                            }
                        }
                        else if(inp.charAt(0)=='D' && inp.charAt(1)==' ')
                        {
                            String isim1="";
                            int i=2;
                            while(i<inp.length())
                            {
                                isim1+=inp.charAt(i);
                                i++;
                            }
                            if(isim1.isEmpty() || isim1.charAt(0)==' ')
                            {
                                System.out.println("Error."); 
                            }
                            else
                            {
                                isim1=isim1.toUpperCase();
                                table.deletePerson(isim1);
                            }
                        }
                        else if(inp.charAt(0)=='L' && inp.charAt(1)==' ')
                        {
                            String isim1="";
                            int i=2;
                            while(i<inp.length())
                            {
                                isim1+=inp.charAt(i);
                                i++;
                            }
                            if(isim1.isEmpty() || isim1.charAt(0)==' ')
                            {
                                System.out.println("Error."); 
                            }
                            else
                            {
                                isim1=isim1.toUpperCase();
                                table.listofFriend(isim1);
                            }
                        }
                        else if(inp.charAt(0)=='O' && inp.charAt(1)==' ')
                        {
                            String isim1="";
                            int i=2;
                            while(i<inp.length())
                            {
                                isim1+=inp.charAt(i);
                                i++;
                            }
                            if(isim1.isEmpty() || isim1.charAt(0)==' ')
                            {
                                System.out.println("Error."); 
                            }
                            else
                            {
                                isim1=isim1.toUpperCase();
                                table.ortakBul(isim1);
                            }
                        }
                        else if(inp.charAt(0)=='F' && inp.charAt(1)==' ')
                        {
                            String isim1="";
                            String isim2="";
                            int i=2;
                            while(inp.charAt(i)!=' ')
                            {
                                isim1+=inp.charAt(i);
                                i++;
                                if(i>=inp.length())
                                {
                                    break;
                                }
                            }
                            i++;
                            while(i<inp.length())
                            {
                                isim2+=inp.charAt(i);
                                i++;
                            }
                            if(isim1.isEmpty() || isim1.charAt(0)==' ' || isim2.isEmpty() || isim2.charAt(0)==' ')
                            {
                                System.out.println("Error."); 
                            }
                            else
                            {
                                isim1=isim1.toUpperCase();
                                isim2=isim2.toUpperCase();
                                table.beFriend(isim1,isim2);
                            }
                        }
                        else if(inp.charAt(0)=='E' && inp.charAt(1)==' ')
                        {
                            String isim1="";
                            String isim2="";
                            int i=2;
                            while(inp.charAt(i)!=' ')
                            {
                                isim1+=inp.charAt(i);
                                i++;
                                if(i>=inp.length())
                                {
                                    break;
                                }
                            }
                            i++;
                            while(i<inp.length())
                            {
                                isim2+=inp.charAt(i);
                                i++;
                            }
                            if(isim1.isEmpty() || isim1.charAt(0)==' ' || isim2.isEmpty() || isim2.charAt(0)==' ')
                            {
                                System.out.println("Error."); 
                            }
                            else
                            {
                                isim1=isim1.toUpperCase();
                                isim2=isim2.toUpperCase();
                                table.deleteFriendship(isim1,isim2);
                            }
                        }
                        else if(inp.charAt(0)=='S' && inp.charAt(1)==' ')
                        {
                            String isim1="";
                            String isim2="";
                            int i=2;
                            while(inp.charAt(i)!=' ')
                            {
                                isim1+=inp.charAt(i);
                                i++;
                                if(i>=inp.length())
                                {
                                    break;
                                }
                            }
                            i++;
                            while(i<inp.length())
                            {
                                isim2+=inp.charAt(i);
                                i++;
                            }
                            if(isim1.isEmpty() || isim1.charAt(0)==' ' || isim2.isEmpty() || isim2.charAt(0)==' ')
                            {
                                System.out.println("Error."); 
                            }
                            else
                            {
                                isim1=isim1.toUpperCase();
                                isim2=isim2.toUpperCase();
                                table.areTheyFriend(isim1,isim2,1);
                            }
                        }
                        else
                        {
                            System.out.println("Error.");
                        }
                    }
                }
                catch(IOException e) 
                {
                    System.out.println("The text file could not find.");
                }
            }
            else
            {
                System.out.println("Error.");
            }
        }
    }
}