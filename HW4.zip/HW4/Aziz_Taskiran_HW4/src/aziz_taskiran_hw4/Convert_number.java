package aziz_taskiran_hw4;
/**
 *
 * @author aziz
 */
public class Convert_number 
{
    public int getKey(String str)
    {
        int i,toplam=0;
    
        for(i=0;i<str.length();i++)
        {
            toplam+=(str.charAt(i)*Math.pow(10, i));
        }
        return toplam;
    }
}
        
