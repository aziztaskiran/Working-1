package aziz_taskiran_hw4;

/**
 *
 * @author aziz
 */
public class Hash_Table 
{
    private int size=1009;
    Convert_number password=new Convert_number();
    Person[] array;
    public Hash_Table()
    {
        int i;
        array=new Person[size];
        for(i=0;i<size;i++)
        {
           array[i]=null;
        }
    }
    public int addPerson(String add, int x)
    {
        int b;
        int number=password.getKey(add);
        int yer=number%size;
        if(array[yer]==null || array[yer].element.equals("---") )
        {
            array[yer]=new Person();
            array[yer].element=add;
            array[yer].index=yer;
            if(x==1)
            {
                System.out.println(array[yer].element+" is created.");
            }
        }
        else
        {
            for(b=yer;b<size;b++)
            {
                if(array[b]!=null)
                {
                    if(array[b].element.equals(add))
                    {
                        if(x==1)
                        {
                            System.out.println(array[b].element+" can not be created.");
                        }
                        return 0;
                    }
                }
                if(b!=(size-1))
                {
                    if(array[b]==null || array[b].element.equals("---"))
                    {
                        array[b]=new Person();
                        array[b].element=add;
                        array[b].index=b;
                        if(x==1)
                        {
                            System.out.println(array[b].element+" is created.");
                        }
                        break;
                    }
                }
                else
                {
                    if(array[b]==null || array[b].element.equals("---"))
                    {
                        array[b]=new Person();
                        array[b].element=add;
                        array[b].index=b;
                        if(x==1)
                        {
                            System.out.println(array[b].element+" is created.");
                        }
                        break;
                    }
                    b=-1;
                }
            }
        }
        return 1;
    }
    public int beFriend(String bir ,String iki)
    {
        int c,tut1=0,tut2=0,d;
        int number1=password.getKey(bir);
        int yer1=number1%size;
        int number2=password.getKey(iki);
        int yer2=number2%size;
        String new1=bir+"&"+iki;
        String new2=iki+"&"+bir;
        int number3=password.getKey(new1);
        int yer3=number3%size;
        for(c=yer3;c<size;c++)
        {
            if(c!=(size-1))
            {
                if(array[c]==null)
                {
                    break;
                }
                if(array[c].element.equals(new1))
                {
                    System.out.println(bir+" and "+iki+" are already friends.");
                    return 0;
                }
            }
            else
            {
                if(array[c]==null)
                {
                    break;
                }
                if(array[c].element.equals(new1))
                {
                    System.out.println(bir+" and "+iki+" are already friends.");
                    return 0;
                }
                c=-1;
            }
            
        }
        for(c=yer1;c<size;c++)
        {
            if(c!=(size-1))
            {
                if(array[c]==null)
                {
                    System.out.println(bir+" and "+iki+" can not be friend.");
                    return 0;
                }
                if(array[c].element.equals(bir))
                {
                    tut1=c;
                    break;
                }
            }
            else
            {
                if(array[c]==null)
                {
                    System.out.println(bir+" and "+iki+" can not be friend.");
                    return 0;
                }
                if(array[c].element.equals(bir))
                {
                    tut1=c;
                    break;
                }
                c=-1;
            }
        }
        for(c=yer2;c<size;c++)
        {
            if(c!=(size-1))
            {
                if(array[c]==null)
                {
                    System.out.println(bir+" and "+iki+" can not be friend.");
                    return 0;
                }
                if(array[c].element.equals(iki))
                {
                    tut2=c;
                    break;
                }
            }
            else
            {
                if(array[c]==null)
                {
                    System.out.println(bir+" and "+iki+" can not be friend.");
                    return 0;
                }
                if(array[c].element.equals(iki))
                {
                    tut2=c;
                    break;
                }
                c=-1;
            }
        }
        Person gecici;
        gecici=array[tut1];
        Person newperson1 =new Person();
        if(gecici.next==null)
        {
            gecici.next=newperson1;
            newperson1.element=array[tut2].element;
            newperson1.index=array[tut2].index;
        }
        else
        {
            newperson1.next=gecici.next;
            gecici.next=newperson1;
            newperson1.element=array[tut2].element;
            newperson1.index=array[tut2].index;
        }
        gecici=array[tut2];
        Person newperson2 =new Person();
        if(gecici.next==null)
        {
            gecici.next=newperson2;
            newperson2.element=array[tut1].element;
            newperson2.index=array[tut1].index;
        }
        else
        {
            newperson2.next=gecici.next;
            gecici.next=newperson2;
            newperson2.element=array[tut1].element;
            newperson2.index=array[tut1].index;
        }
        addPerson(new1,0);
        addPerson(new2,0);
        System.out.println(bir+" and "+iki+" are friends now.");
        return 1;
    }
    public int listofFriend(String list)
    {
        int c,tut1=0;
        int number=password.getKey(list);
        int yer=number%size;
        for(c=yer;c<size;c++)
        {
            if(c!=(size-1))
            {
                if(array[c]==null)
                {
                    System.out.println(list+" is not in the list.");
                    return 0;
                }
                if(array[c].element.equals(list))
                {
                    tut1=c;
                    break;
                }
            }
            else
            {
                if(array[c]==null)
                {
                    System.out.println(list+" is not in the list.");
                    return 0;
                }
                if(array[c].element.equals(list))
                {
                    tut1=c;
                    break;
                }
                c=-1;
            }
        }
        Person gecici;
        gecici=array[tut1];
        if(gecici.next==null)
        {
            System.out.println(list+" has No friend.");
            return 0;
        }
        while(gecici.next!=null)
        {
            gecici=gecici.next;
            System.out.println(gecici.element);
        }
        return 1;
    }
    public int areTheyFriend(String bir,String iki,int x)
    {
        String str=bir+"&"+iki;
        int c;
        int number=password.getKey(str);
        int yer=number%size;
        for(c=yer;c<size;c++)
        {
            if(c!=(size-1))
            {
                if(array[c]==null)
                {
                    if(x==1)
                    {
                        System.out.println("No.");
                    }
                    return 0;
                }
                if(array[c].element.equals(str))
                {
                   if(x==1)
                   {
                       System.out.println("Yes.");
                   }
                   return 1;
                }
            }
            else
            {
                if(array[c]==null)
                {
                    if(x==1)
                    {
                        System.out.println("No.");
                    }
                    return 0;
                }
                if(array[c].element.equals(str))
                {
                    if(x==1)
                    {
                        System.out.println("Yes.");
                    }
                    return 1;
                }
                c=-1;
            }
        }
        return 1;
    }
    public int deleteFriendship(String ilk,String son)
    {
        int x=0;
        if(x==areTheyFriend(ilk,son,0))
        {
            System.out.println(ilk+" "+son+" can not be erased.");
            return 0;
        }
        int c,tut1=0,tut2=0,d;
        int number1=password.getKey(ilk);
        int yer1=number1%size;
        int number2=password.getKey(son);
        int yer2=number2%size;
        for(c=yer1;c<size;c++)
        {
            if(c!=(size-1))
            {
                if(array[c]==null)
                {
                    System.out.println(ilk+" "+son+" can not be erased.");
                    return 0;
                }
                if(array[c].element.equals(ilk))
                {
                    tut1=c;
                    break;
                }
            }
            else
            {
                if(array[c]==null)
                {
                    System.out.println(ilk+" "+son+" can not be erased.");
                    return 0;
                }
                if(array[c].element.equals(ilk))
                {
                    tut1=c;
                    break;
                }
                c=-1;
            }
        }
        for(c=yer2;c<size;c++)
        {
            if(c!=(size-1))
            {
                if(array[c]==null)
                {
                    System.out.println(ilk+" "+son+" can not be erased.");
                    return 0;
                }
                if(array[c].element.equals(son))
                {
                    tut2=c;
                    break;
                }
            }
            else
            {
                if(array[c]==null)
                {
                    System.out.println(ilk+" "+son+" can not be erased.");
                    return 0;
                }
                if(array[c].element.equals(son))
                {
                    tut2=c;
                    break;
                }
                c=-1;
            }
        }
        Person gecici;
        Person follow;
        gecici=array[tut1];
        follow=array[tut1];
        while(!gecici.element.equals(son))
        {
            follow=gecici;
            gecici=gecici.next;
        }
        follow.next=gecici.next;
        gecici.next=null;
        gecici=array[tut2];
        follow=array[tut2];
        while(!gecici.element.equals(ilk))
        {
            follow=gecici;
            gecici=gecici.next;
        }
        follow.next=gecici.next;
        gecici.next=null;
        System.out.println(ilk+" and "+son+" are no more friends.");
        String name1=ilk+"&"+son;
        String name2=son+"&"+ilk;
        number1=password.getKey(name1);
        yer1=number1%size;
        number2=password.getKey(name2);
        yer2=number2%size;
        for(c=yer1;c<size;c++)
        {
            if(c!=(size-1))
            {
                if(array[c]==null)
                {
                    return 0;
                }
                if(array[c].element.equals(name1))
                {
                    array[c].element="---";
                    break;
                }
            }
            else
            {
                if(array[c]==null)
                {
                    return 0;
                }
                if(array[c].element.equals(name1))
                {
                    array[c].element="---";
                    break;
                }
                c=-1;
            }
        }
        for(c=yer2;c<size;c++)
        {
            if(c!=(size-1))
            {
                if(array[c]==null)
                {
                    return 0;
                }
                if(array[c].element.equals(name2))
                {
                    array[c].element="---";
                    break;
                }
            }
            else
            {
                if(array[c]==null)
                {
                    return 0;
                }
                if(array[c].element.equals(name2))
                {
                    array[c].element="---";
                    break;
                }
                c=-1;
            }
        }
        return 1;
    }
    public int deletePerson(String sil)
    {
        int a,c,tut1=0;
        int number=password.getKey(sil);
        int yer=number%size;
        for(c=yer;c<size;c++)
        {
            if(c!=(size-1))
            {
                if(array[c]==null)
                {
                    System.out.println(sil+" is not in the list.");
                    return 0;
                }
                if(array[c].element.equals(sil))
                {
                    tut1=c;
                    break;
                }
            }
            else
            {
                if(array[c]==null)
                {
                    System.out.println(sil+" is not in the list.");
                    return 0;
                }
                if(array[c].element.equals(sil))
                {
                    tut1=c;
                    break;
                }
                c=-1;
            }
        }
        if(array[tut1].next==null)
        {
            array[tut1].element="---";
            System.out.println(sil+" is deleted.");
            return 1;
        }
        Person gecici;
        gecici=array[tut1];
        while(gecici.next!=null)
        {
            gecici=gecici.next;
            Person gecici2;
            Person follow;
            gecici2=array[gecici.index];
            follow=array[gecici.index];
            while(gecici2.next!=null)
            {
                follow=gecici2;
                gecici2=gecici2.next;
                if(gecici2.element.equals(array[tut1].element))
                {
                    follow.next=gecici2.next;
                    String str1=gecici2.element+"&"+gecici.element;
                    String str2=gecici.element+"&"+gecici2.element;
                    int number1=password.getKey(str1);
                    int yer1=number1%size;
                    int number2=password.getKey(str2);
                    int yer2=number2%size;
                    while(!array[yer1].element.equals(str1))
                    {
                        yer1++;
                        if(yer1>(size-1))
                        {
                            yer1=0;
                        }
                    }
                    while(!array[yer2].element.equals(str2))
                    {
                        yer2++;
                        if(yer2>(size-1))
                        {
                            yer2=0;
                        }
                    }
                    array[yer1].element="---";
                    array[yer2].element="---";
                    break;
                }
            }
        }
        array[tut1].next=null;
        array[tut1].element="---";
        System.out.println(sil+" is deleted.");
        return 1;
    }
    public int ortakBul(String ortak)
    {
        int c,tut1=0;
        int number=password.getKey(ortak);
        int yer=number%size;
        for(c=yer;c<size;c++)
        {
            if(c!=(size-1))
            {
                if(array[c]==null)
                {
                    System.out.println(ortak+" is not in the list.");
                    return 0;
                }
                if(array[c].element.equals(ortak))
                {
                    tut1=c;
                    break;
                }
            }
            else
            {
                if(array[c]==null)
                {
                    System.out.println(ortak+" is not in the list.");
                    return 0;
                }
                if(array[c].element.equals(ortak))
                {
                    tut1=c;
                    break;
                }
                c=-1;
            }
        }
        Person gecici;
        Person gecici2;
        gecici=array[tut1];
        if(gecici.next==null)
        {
            System.out.println(ortak+" has No friend.");
            return 0;
        }
        listofFriend(ortak);
        while(gecici.next!=null)
        {
            gecici2=array[gecici.next.index];
            while(gecici2.next!=null)
            {
                if(!gecici2.next.element.equals(array[tut1].element))
                {
                    System.out.println("*"+gecici2.next.element);
                }
                gecici2=gecici2.next;
            }
            gecici=gecici.next;
        }
        return 1;
    }
}